import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CatalogoInteg {
    private List<Integracion_Apis> integraciones;

    public CatalogoInteg() {
        integraciones = new ArrayList<>();
    }

    public List<Integracion_Apis> getIntegraciones() {
        return integraciones;
    }

    public void agregarIntegracion(Integracion_Apis api) {
        if (api != null && buscarPorId(api.getIdentificador()) == null) {
            integraciones.add(api);
        }
    }

    public void cargarDatosIniciales() {
        if (!integraciones.isEmpty()) {
            return;
        }
        agregarIntegracion(new Pasarelapago(
                "PAY001", "PayPal", true, 120,
                crearParametros("Moneda", "USD", "Autenticacion", "OAuth"),
                "Billetera digital"));

        agregarIntegracion(new Pasarelapago(
                "PAY002", "VisaNet", true, 95,
                crearParametros("Moneda", "GTQ", "Autenticacion", "Token"),
                "Tarjeta de credito"));

        agregarIntegracion(new Pasarelapago(
                "PAY003", "Mastercard", true, 110,
                crearParametros("Moneda", "GTQ", "Autenticacion", "Token"),
                "Tarjeta de debito"));

        agregarIntegracion(new Pasarelapago(
                "PAY004", "Transferencia Bancaria", true, 150,
                crearParametros("Banco", "Banco Nacional", "Moneda", "GTQ"),
                "Transferencia"));

        agregarIntegracion(new Proveedor_Transporte(
                "LOG001", "Cargo Express", true, 180,
                crearParametros("Formato", "JSON", "Seguimiento", "Activo"),
                "Guatemala"));

        agregarIntegracion(new Proveedor_Transporte(
                "LOG002", "DHL", true, 210,
                crearParametros("Formato", "XML", "Seguimiento", "Activo"),
                "Internacional"));

        agregarIntegracion(new Proveedor_Transporte(
                "LOG003", "FedEx", true, 195,
                crearParametros("Formato", "JSON", "Seguimiento", "Activo"),
                "Internacional"));

        // 3. Certificadores FEL
        agregarIntegracion(new CertificadorFEL(
                "FEL001", "Infile", true, 130,
                crearParametros("Formato", "XML", "Version", "1.0"),
                "Factura electronica"));

        agregarIntegracion(new CertificadorFEL(
                "FEL002", "Megaprint", true, 145,
                crearParametros("Formato", "XML", "Version", "1.0"),
                "Factura electronica"));

        agregarIntegracion(new CertificadorFEL(
                "FEL003", "G4S", true, 160,
                crearParametros("Formato", "XML", "Version", "1.0"),
                "Documento tributario"));
    }

    private Map<String, String> crearParametros(String clave1, String valor1, String clave2, String valor2) {
        Map<String, String> parametros = new HashMap<>();
        parametros.put(clave1, valor1);
        parametros.put(clave2, valor2);
        return parametros;
    }

    public Integracion_Apis buscarPorId(String id) {
        if (id == null) {
            return null;
        }
        for (Integracion_Apis api : integraciones) {

            if (api.getIdentificador().equalsIgnoreCase(id)) {
                return api;
            }
        }
        return null;
    }

    public void listarIntegraciones() {
        for (Integracion_Apis api : integraciones) {
            System.out.println(api);
        }
    }

    public void ordenarPorLatencia() {
        Collections.sort(integraciones);
    }
}