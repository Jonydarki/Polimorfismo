
import java.util.Map;

public class Proveedor_Transporte extends Integracion_Apis implements Consultable {
    private String zonaCobertura;

    public Proveedor_Transporte(String identificador, String nombre,boolean activa, double latenciaPromedio, Map<String, String> parametrosConfiguracion, String zonaCobertura) {
        super(identificador, nombre, "Proveedor logistico", activa, latenciaPromedio, parametrosConfiguracion);
        this.zonaCobertura = zonaCobertura;
    }

    public String getZonaCobertura() {
        return zonaCobertura;
    }

    public void setZonaCobertura(String zonaCobertura) {
        this.zonaCobertura = zonaCobertura;
    }

    @Override
    public String consultar(String criterio) {
        if (!consultarEstadoConexion()) {
            return "Error: proveedor logistico desconectado.";
        }
        if (criterio == null || criterio.trim().isEmpty()) {
            return "Error: debe proporcionar un criterio de consulta.";
        }
        registrarAuditoria("Consulta realizada: " + criterio);
        return "Consulta realizada para: " + criterio
                + "\nProveedor: " + getNombre()
                + "\nZona de cobertura: " + zonaCobertura;
    }
    
    @Override
    public String toString() {

        return super.toString()
                + "\nZona de cobertura: " + zonaCobertura;
    }
}