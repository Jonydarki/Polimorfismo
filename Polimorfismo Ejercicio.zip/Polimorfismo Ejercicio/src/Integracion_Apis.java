import java.util.Map;
import java.util.Objects;

public abstract class Integracion_Apis implements Comparable<Integracion_Apis>, Auditable {
    private String identificador;
    private String nombre;
    private String tipo;
    private boolean activa;
    private double latenciaPromedio;
    private Map<String, String> parametrosConfiguracion;

    public Integracion_Apis(String identificador, String nombre, String tipo, boolean activa, double latenciaPromedio, Map<String, String> parametrosConfiguracion) {
        this.identificador = identificador;
        this.nombre = nombre;
        this.tipo = tipo;
        this.activa = activa;
        this.latenciaPromedio = latenciaPromedio;
        this.parametrosConfiguracion = parametrosConfiguracion;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    public double getLatenciaPromedio() {
        return latenciaPromedio;
    }

    public void setLatenciaPromedio(double latenciaPromedio) {
        this.latenciaPromedio = latenciaPromedio;
    }

    public Map<String, String> getParametrosConfiguracion() {
        return parametrosConfiguracion;
    }

    public void setParametrosConfiguracion(Map<String, String> parametrosConfiguracion) {
        this.parametrosConfiguracion = parametrosConfiguracion;
    }

    public boolean consultarEstadoConexion() {
        return activa;
    }

    @Override
    public void registrarAuditoria(String accion) {
        System.out.println("[AUDITORIA] " + nombre + ": " + accion);
    }

    @Override
    public int compareTo(Integracion_Apis otra) {
        return Double.compare(this.latenciaPromedio, otra.latenciaPromedio);
    }

    @Override
    public String toString() {
        return "ID: " + identificador
                + "\nNombre: " + nombre
                + "\nTipo: " + tipo
                + "\nEstado: " + (activa ? "Activa" : "Inactiva")
                + "\nLatencia promedio: " + latenciaPromedio + " ms"
                + "\nParametros de configuracion: " + parametrosConfiguracion;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Integracion_Apis otra = (Integracion_Apis) obj;
        return Objects.equals(identificador, otra.identificador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClass(), identificador);
    }
}
