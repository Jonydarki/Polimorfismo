import java.util.List;
import java.util.Scanner;

public class Consola {
    private Scanner entrada;

    public Consola() {
        entrada = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n-----------------------------------------");
        System.out.println("   Sistema de Interaciones API   ");
        System.out.println("Bienvenido, ¿Como lo podemos ayudar hoy?");
        System.out.println("-----------------------------------------");
        System.out.println("1. Listar integraciones");
        System.out.println("2. Buscar integracion por ID");
        System.out.println("3. Ordenar por latencia promedio");
        System.out.println("4. Salir");
        System.out.println("-----------------------------------------");
        System.out.print("Seleccione una opcion: ");
    }

    public int leerOpcion() {
        while (!entrada.hasNextInt()) {
            System.out.println("Ingrese una opcion numerica.");
            entrada.next();
            System.out.print("Seleccione una opcion: ");
        }
        int opcion = entrada.nextInt();
        entrada.nextLine();
        return opcion;
    }

    public String leerTexto(String mensaje) {
        System.out.println(mensaje);
        return entrada.nextLine();
    }
    public void mostrarIntegraciones(List<Integracion_Apis> integraciones) {
        System.out.println("\n------------------Catalogo de Integraciones-----------------------");
        for (Integracion_Apis api : integraciones) {
            System.out.println(api);
            System.out.println("-----------------------------------------");
        }
    }

    public void mostrarDetalle(Integracion_Apis api) {
        System.out.println("\n------------------Detalles de la Integracion---------------------");
        System.out.println(api);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println("\n" + mensaje);
    }
}
