public interface Consultable {
    String consultar(String criterio);
}