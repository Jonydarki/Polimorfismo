public class Main {

    public static void main(String[] args) {

        CatalogoInteg catalogo = new CatalogoInteg();

        Consola vista = new Consola();

        Integ_Control controlador =
                new Integ_Control(catalogo, vista);

        controlador.iniciar();
    }
}