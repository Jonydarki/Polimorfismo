
import java.util.List;

public class Controlador {

    private CatalogoInteg catalogo;
    private Consola vista;

    public Controlador(CatalogoInteg catalogo, Consola vista) {
        this.catalogo = catalogo;
        this.vista = vista;
    }

    public void iniciar() {
        catalogo.cargarDatosIniciales();
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1:
                    listarIntegraciones();
                    break;
                case 2:
                    buscarIntegracion();
                    break;
                case 3:
                    ordenarIntegraciones();
                    break;
                case 4:
                    vista.mostrarMensaje("Finalizando el programa...");
                    break;
                default:
                    vista.mostrarMensaje("Opcion no valida.");
            }

        } while (opcion != 4);
    }

    public void listarIntegraciones() {
        List<Integracion_Apis> lista = catalogo.getIntegraciones();
        if (lista.isEmpty()) {
            vista.mostrarMensaje("No existen integraciones registradas.");
        } else {
            vista.mostrarIntegraciones(lista);
        }
    }

    public void buscarIntegracion() {
        String id = vista.leerTexto("Ingrese el identificador de la API:");
        Integracion_Apis integracion = catalogo.buscarPorId(id);
        if (integracion != null) {
            vista.mostrarDetalle(integracion);
        } else {
            vista.mostrarMensaje("No se encontro una integracion con ese ID.");
        }
    }

    public void ordenarIntegraciones() {
        catalogo.ordenarPorLatencia();
        vista.mostrarMensaje("Integraciones ordenadas por latencia promedio.");
        listarIntegraciones();
    }

    public void ejecutarOperacion(Transaccional servicio, double monto) {
        boolean resultado = servicio.procesarCobro(monto);
        if (resultado) {
            vista.mostrarMensaje("Cobro procesado correctamente.");
        } else {
            vista.mostrarMensaje("No fue posible procesar el cobro.");
        }
    }

    public void ejecutarOperacion(Consultable servicio, String criterio) {
        String resultado = servicio.consultar(criterio);
        vista.mostrarMensaje("Resultado de la consulta: " + resultado);
    }

    public void ejecutarOperacion(Documentable servicio, String datos) {
        String resultado = servicio.generarDocumento(datos);
        vista.mostrarMensaje("Documento generado: " + resultado);
    }

    public void solicitarReintegro(Integracion_Apis api, double monto) {
        if (api instanceof Transaccional) {
            Transaccional servicio = (Transaccional) api;
            boolean resultado = servicio.procesarReintegro(monto);
            if (resultado) {
                vista.mostrarMensaje("Reintegro procesado correctamente.");
            } else {
                vista.mostrarMensaje("No fue posible procesar el reintegro.");
            }
        } else {
            vista.mostrarMensaje(
                "Operacion ignorada: esta integracion no admite reintegros."
            );
        }
    }
}
