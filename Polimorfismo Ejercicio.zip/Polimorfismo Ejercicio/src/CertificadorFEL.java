import java.util.Map;

public class CertificadorFEL extends Integracion_Apis implements Documentable {
    private String tipoDocumento;

    public CertificadorFEL(String identificador, String nombre, boolean activa, double latenciaPromedio, Map<String, String> parametrosConfiguracion, String tipoDocumento) {
        super(identificador, nombre, "Certificador FEL", activa, latenciaPromedio, parametrosConfiguracion);
        this.tipoDocumento = tipoDocumento;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    @Override
    public String generarDocumento(String datos) {
        if (!consultarEstadoConexion()) {
            return "Error: certificador FEL desconectado.";
        }
        if (datos == null || datos.trim().isEmpty()) {
            return "Error: debe proporcionar los datos del documento.";
        }
        registrarAuditoria("Documento FEL generado.");
        return "Documento " + tipoDocumento
                + " generado correctamente."
                + "\nDatos: " + datos
                + "\nCertificador: " + getNombre();
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nTipo de documento: " + tipoDocumento;
    }
}