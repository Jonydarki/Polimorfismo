public interface Auditable {
    void registrarAuditoria(String accion);
}