import java.util.Map;

public class Pasarelapago extends Integracion_Apis implements Transaccional {
    private String metodoPago;
    public Pasarelapago(String identificador, String nombre, boolean activa, double latenciaPromedio, Map<String, String> parametrosConfiguracion, String metodoPago) {
        super(identificador, nombre, "Pasarela de pago", activa, latenciaPromedio, parametrosConfiguracion);
        this.metodoPago = metodoPago;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    @Override
    public boolean procesarCobro(double monto) {
        if (!consultarEstadoConexion() || monto <= 0) {
            return false;
        }
        registrarAuditoria("Cobro procesado: Q" + monto);
        return true;
    }

    @Override
    public boolean procesarReintegro(double monto) {
        if (!consultarEstadoConexion() || monto <= 0) {
            return false;
        }
        registrarAuditoria("Reintegro procesado: Q" + monto);
        return true;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nMetodo de pago: " + metodoPago;
    }
}